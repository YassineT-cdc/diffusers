(function () {
    'use strict';

    var InferiorLogic = window.InferiorLogic;
    var InferiorGame = InferiorLogic.InferiorGame;
    var isValidCapture = InferiorLogic.isValidCapture;

    var elements = {
        app: document.getElementById('app'),
        board: document.getElementById('board'),
        boardFrame: document.getElementById('board-frame'),
        fxLayer: document.getElementById('fx-layer'),
        dragGhost: document.getElementById('drag-ghost'),
        overlay: document.getElementById('overlay'),
        subtitle: document.getElementById('subtitle'),
        roundPill: document.getElementById('round-pill'),
        turnPill: document.getElementById('turn-pill'),
        turnHelper: document.getElementById('turn-helper'),
        scoreRed: document.getElementById('score-red'),
        scoreBlue: document.getElementById('score-blue'),
        roundRed: document.getElementById('round-red'),
        roundBlue: document.getElementById('round-blue'),
        panelRed: document.getElementById('panel-red'),
        panelBlue: document.getElementById('panel-blue'),
        statusKicker: document.getElementById('status-kicker'),
        statusTitle: document.getElementById('status-title'),
        statusMessage: document.getElementById('status-message'),
        primaryButton: document.getElementById('primary-button'),
        secondaryButton: document.getElementById('secondary-button'),
        overlayStartButton: document.getElementById('overlay-start-button'),
        overlayFullscreenButton: document.getElementById('overlay-fullscreen-button'),
        fullscreenButton: document.getElementById('fullscreen-button'),
        musicButton: document.getElementById('music-button')
    };

    var state = {
        game: new InferiorGame(),
        snapshot: null,
        selectedSourceIndex: null,
        drag: null,
        transientStatus: null,
        transientTimerId: 0,
        attemptedFullscreen: false,
        audio: null
    };

    function AudioEngine() {
        this.enabled = true;
        this.started = false;
        this.context = null;
        this.masterGain = null;
        this.musicGain = null;
        this.nextStepTime = 0;
        this.stepIndex = 0;
        this.schedulerId = 0;
        this.tempo = 108;
    }

    AudioEngine.prototype.ensureStarted = function () {
        var AudioContextConstructor = window.AudioContext || window.webkitAudioContext;
        var self = this;

        if (!this.enabled || this.started || !AudioContextConstructor) {
            return Promise.resolve();
        }

        this.context = new AudioContextConstructor();
        this.masterGain = this.context.createGain();
        this.musicGain = this.context.createGain();
        this.masterGain.gain.value = 0.22;
        this.musicGain.gain.value = 0.10;
        this.musicGain.connect(this.masterGain);
        this.masterGain.connect(this.context.destination);
        this.nextStepTime = this.context.currentTime + 0.05;
        this.stepIndex = 0;
        this.started = true;

        this.schedulerId = window.setInterval(function () {
            self.scheduleMusic();
        }, 120);

        return this.context.resume().catch(function () {
            return undefined;
        });
    };

    AudioEngine.prototype.setEnabled = function (enabled) {
        this.enabled = enabled;

        if (!this.started || !this.masterGain) {
            return;
        }

        this.masterGain.gain.cancelScheduledValues(this.context.currentTime);
        this.masterGain.gain.linearRampToValueAtTime(enabled ? 0.22 : 0.0001, this.context.currentTime + 0.2);
    };

    AudioEngine.prototype.playTone = function (frequency, startTime, duration, type, volume, destination) {
        var oscillator;
        var gainNode;

        if (!this.started || !this.context || !this.enabled) {
            return;
        }

        oscillator = this.context.createOscillator();
        gainNode = this.context.createGain();
        oscillator.type = type || 'sine';
        oscillator.frequency.setValueAtTime(frequency, startTime);
        gainNode.gain.setValueAtTime(0.0001, startTime);
        gainNode.gain.exponentialRampToValueAtTime(volume || 0.05, startTime + 0.02);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
        oscillator.connect(gainNode);
        gainNode.connect(destination || this.musicGain || this.masterGain);
        oscillator.start(startTime);
        oscillator.stop(startTime + duration + 0.03);
    };

    AudioEngine.prototype.playNoiseBurst = function (startTime, duration, volume) {
        var buffer;
        var channel;
        var source;
        var gainNode;
        var index;

        if (!this.started || !this.context || !this.enabled) {
            return;
        }

        buffer = this.context.createBuffer(1, Math.max(1, Math.floor(this.context.sampleRate * duration)), this.context.sampleRate);
        channel = buffer.getChannelData(0);
        for (index = 0; index < channel.length; index += 1) {
            channel[index] = (Math.random() * 2 - 1) * (1 - index / channel.length);
        }

        source = this.context.createBufferSource();
        gainNode = this.context.createGain();
        source.buffer = buffer;
        gainNode.gain.setValueAtTime(volume, startTime);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
        source.connect(gainNode);
        gainNode.connect(this.masterGain);
        source.start(startTime);
        source.stop(startTime + duration);
    };

    AudioEngine.prototype.scheduleMusic = function () {
        var now;
        var step;
        var melody;
        var bassLine;
        var melodyOffset;

        if (!this.started || !this.context || !this.enabled) {
            return;
        }

        now = this.context.currentTime;
        melody = [220, 246.94, 293.66, 329.63, 392, 329.63, 293.66, 246.94];
        bassLine = [55, 55, 61.74, 65.41, 73.42, 65.41, 61.74, 55];

        while (this.nextStepTime < now + 0.35) {
            step = this.stepIndex % 16;
            melodyOffset = melody[this.stepIndex % melody.length];

            if (step % 4 === 0) {
                this.playTone(bassLine[this.stepIndex % bassLine.length], this.nextStepTime, 0.34, 'triangle', 0.06);
                this.playNoiseBurst(this.nextStepTime, 0.08, 0.02);
            }

            this.playTone(melodyOffset, this.nextStepTime, 0.12, step % 2 === 0 ? 'sine' : 'triangle', 0.035);
            if (step % 8 === 4) {
                this.playTone(melodyOffset * 1.5, this.nextStepTime, 0.22, 'square', 0.015);
            }

            this.nextStepTime += 60 / this.tempo / 4;
            this.stepIndex += 1;
        }
    };

    AudioEngine.prototype.playCapture = function (gain, playerId) {
        var now;
        var baseFrequency;

        if (!this.started || !this.context || !this.enabled) {
            return;
        }

        now = this.context.currentTime;
        baseFrequency = playerId === 'red' ? 196 : 261.63;
        this.playTone(baseFrequency, now, 0.15, 'square', 0.08, this.masterGain);
        this.playTone(baseFrequency * 1.25, now + 0.05, 0.20, 'triangle', 0.06, this.masterGain);
        this.playTone(baseFrequency * (1 + Math.min(gain, 16) / 32), now + 0.10, 0.28, 'sine', 0.05, this.masterGain);
    };

    AudioEngine.prototype.playPass = function (playerId) {
        var now;
        var baseFrequency;

        if (!this.started || !this.context || !this.enabled) {
            return;
        }

        now = this.context.currentTime;
        baseFrequency = playerId === 'red' ? 155.56 : 207.65;
        this.playTone(baseFrequency, now, 0.08, 'sawtooth', 0.03, this.masterGain);
        this.playTone(baseFrequency * 0.8, now + 0.05, 0.12, 'triangle', 0.02, this.masterGain);
    };

    AudioEngine.prototype.playRoundEnd = function (winnerId) {
        var now;
        var baseFrequency;

        if (!this.started || !this.context || !this.enabled) {
            return;
        }

        now = this.context.currentTime;
        baseFrequency = winnerId === 'blue' ? 220 : 174.61;
        this.playTone(baseFrequency, now, 0.18, 'triangle', 0.05, this.masterGain);
        this.playTone(baseFrequency * 1.5, now + 0.1, 0.25, 'square', 0.04, this.masterGain);
        this.playTone(baseFrequency * 2, now + 0.2, 0.35, 'sine', 0.03, this.masterGain);
    };

    AudioEngine.prototype.playVictory = function (winnerId) {
        var now;
        var baseFrequency;

        if (!this.started || !this.context || !this.enabled) {
            return;
        }

        now = this.context.currentTime;
        baseFrequency = winnerId === 'blue' ? 246.94 : 196;
        this.playTone(baseFrequency, now, 0.24, 'triangle', 0.08, this.masterGain);
        this.playTone(baseFrequency * 1.333, now + 0.08, 0.24, 'triangle', 0.07, this.masterGain);
        this.playTone(baseFrequency * 2, now + 0.18, 0.5, 'square', 0.05, this.masterGain);
    };

    function capitalize(value) {
        return value.charAt(0).toUpperCase() + value.slice(1);
    }

    function initialize() {
        state.audio = new AudioEngine();
        state.snapshot = state.game.getSnapshot();
        bindEvents();
        render();
    }

    function bindEvents() {
        elements.primaryButton.addEventListener('click', handlePrimaryAction);
        elements.secondaryButton.addEventListener('click', backToTitle);
        elements.overlayStartButton.addEventListener('click', handlePrimaryAction);
        elements.overlayFullscreenButton.addEventListener('click', function () {
            activateMediaExperience();
            requestFullscreen(true).finally(function () {
                startGameIfNeeded();
            });
        });
        elements.fullscreenButton.addEventListener('click', function () {
            activateMediaExperience();
            toggleFullscreen();
        });
        elements.musicButton.addEventListener('click', toggleMusic);
        elements.board.addEventListener('pointerdown', handleBoardPointerDown);
        elements.board.addEventListener('pointermove', handleBoardPointerMove);
        elements.board.addEventListener('pointerup', handleBoardPointerUp);
        elements.board.addEventListener('pointercancel', cancelDrag);
        elements.board.addEventListener('lostpointercapture', cancelDrag);
        elements.board.addEventListener('click', handleBoardClick);
        document.addEventListener('fullscreenchange', render);
        window.addEventListener('resize', render);
    }

    function handlePrimaryAction() {
        activateMediaExperience();

        if (state.snapshot.phase === 'intro') {
            startGameIfNeeded();
            return;
        }

        if (state.snapshot.phase === 'round-end') {
            state.selectedSourceIndex = null;
            state.drag = null;
            updateSnapshot(state.game.startNextRound());
            return;
        }

        if (state.snapshot.phase === 'game-over') {
            startGameIfNeeded();
        }
    }

    function startGameIfNeeded() {
        if (state.snapshot.phase === 'intro' || state.snapshot.phase === 'game-over') {
            if (!state.attemptedFullscreen) {
                state.attemptedFullscreen = true;
                requestFullscreen(false);
            }

            state.selectedSourceIndex = null;
            cancelDrag();
            updateSnapshot(state.game.startGame());
        }
    }

    function backToTitle() {
        state.game.resetGame();
        state.selectedSourceIndex = null;
        cancelDrag();
        clearTransientStatus();
        updateSnapshot(state.game.getSnapshot());
    }

    function toggleMusic() {
        activateMediaExperience();
        state.audio.enabled = !state.audio.enabled;
        state.audio.setEnabled(state.audio.enabled);
        render();
    }

    function activateMediaExperience() {
        state.audio.ensureStarted();
    }

    function requestFullscreen(force) {
        var target = elements.app;

        if (document.fullscreenElement && !force) {
            return Promise.resolve();
        }

        if (!target.requestFullscreen) {
            return Promise.resolve();
        }

        return target.requestFullscreen().catch(function () {
            return undefined;
        });
    }

    function toggleFullscreen() {
        if (document.fullscreenElement && document.exitFullscreen) {
            document.exitFullscreen();
            return;
        }

        requestFullscreen(true);
    }

    function handleBoardClick(event) {
        var cardElement = event.target.closest('.card');
        var cardIndex;
        var card;
        var sourceIndex;

        if (!cardElement || state.drag) {
            return;
        }

        if (state.snapshot.phase !== 'round-active') {
            return;
        }

        activateMediaExperience();
        cardIndex = Number(cardElement.dataset.index);
        card = state.snapshot.board[cardIndex];

        if (!card) {
            return;
        }

        if (card.owner === state.snapshot.currentPlayerId) {
            if (getMovesForSource(cardIndex).length === 0) {
                shakeCard(cardIndex);
                setTransientStatus('No capture here', 'Choose one of your glowing cards to make a legal move.');
                return;
            }

            state.selectedSourceIndex = cardIndex;
            render();
            return;
        }

        sourceIndex = state.selectedSourceIndex;
        if (sourceIndex !== null && isValidCapture(state.snapshot.board, sourceIndex, cardIndex, state.snapshot.currentPlayerId)) {
            attemptCapture(sourceIndex, cardIndex);
            return;
        }

        shakeCard(cardIndex);
        setTransientStatus('Invalid target', 'Drop or tap onto a smaller adjacent enemy card.');
    }

    function handleBoardPointerDown(event) {
        var cardElement = event.target.closest('.card');
        var sourceIndex;
        var card;
        var validMoves;

        if (!cardElement || state.snapshot.phase !== 'round-active') {
            return;
        }

        sourceIndex = Number(cardElement.dataset.index);
        card = state.snapshot.board[sourceIndex];
        if (!card) {
            return;
        }

        activateMediaExperience();

        if (card.owner !== state.snapshot.currentPlayerId) {
            return;
        }

        validMoves = getMovesForSource(sourceIndex);
        if (validMoves.length === 0) {
            shakeCard(sourceIndex);
            setTransientStatus('No capture here', 'Choose a brighter card with at least one smaller adjacent enemy.');
            return;
        }

        event.preventDefault();
        elements.board.setPointerCapture(event.pointerId);
        state.selectedSourceIndex = sourceIndex;
        state.drag = {
            pointerId: event.pointerId,
            fromIndex: sourceIndex,
            startX: event.clientX,
            startY: event.clientY,
            currentX: event.clientX,
            currentY: event.clientY,
            moved: false,
            hoverTargetIndex: null,
            validTargets: validMoves.map(function (move) {
                return move.toIndex;
            })
        };
        updateDragGhost(sourceIndex, event.clientX, event.clientY);
        render();
    }

    function handleBoardPointerMove(event) {
        var candidateTargetIndex;

        if (!state.drag || state.drag.pointerId !== event.pointerId) {
            return;
        }

        state.drag.currentX = event.clientX;
        state.drag.currentY = event.clientY;
        state.drag.moved = state.drag.moved || distanceBetween(state.drag.startX, state.drag.startY, event.clientX, event.clientY) > 6;
        candidateTargetIndex = findCardIndexFromPoint(event.clientX, event.clientY);
        state.drag.hoverTargetIndex = candidateTargetIndex;
        updateDragGhost(state.drag.fromIndex, event.clientX, event.clientY);
        syncDragClasses();
    }

    function handleBoardPointerUp(event) {
        var targetIndex;
        var isValidDrop;

        if (!state.drag || state.drag.pointerId !== event.pointerId) {
            return;
        }

        targetIndex = findCardIndexFromPoint(event.clientX, event.clientY);
        isValidDrop = targetIndex !== null
            && state.drag.validTargets.indexOf(targetIndex) >= 0
            && isValidCapture(state.snapshot.board, state.drag.fromIndex, targetIndex, state.snapshot.currentPlayerId);

        if (elements.board.hasPointerCapture && elements.board.hasPointerCapture(event.pointerId)) {
            elements.board.releasePointerCapture(event.pointerId);
        }

        if (state.drag.moved && isValidDrop) {
            attemptCapture(state.drag.fromIndex, targetIndex);
            return;
        }

        if (state.drag.moved) {
            shakeCard(state.drag.fromIndex);
            setTransientStatus('Drop on a smaller enemy', 'The target must be adjacent, enemy-owned and strictly lower.');
        }

        cancelDrag();
        render();
    }

    function cancelDrag() {
        state.drag = null;
        elements.dragGhost.classList.add('hidden');
        elements.board.classList.remove('is-dragging');
        syncDragClasses();
    }

    function attemptCapture(fromIndex, toIndex) {
        var sourceCenter = getCardCenter(fromIndex);
        var targetCenter = getCardCenter(toIndex);
        var result = state.game.tryCapture(fromIndex, toIndex);

        if (!result.ok) {
            shakeCard(fromIndex);
            setTransientStatus('Illegal move', 'Only a strictly bigger adjacent card can capture.');
            updateSnapshot(result.snapshot);
            return;
        }

        cancelDrag();
        state.selectedSourceIndex = null;
        spawnCaptureEffects(sourceCenter, targetCenter, result.move);
        state.audio.playCapture(result.move.gain, result.move.actingPlayer);
        updateSnapshot(result.snapshot);
    }

    function updateSnapshot(snapshot) {
        state.snapshot = snapshot;
        processSnapshotEvents(snapshot.events || []);
        render();
    }

    function processSnapshotEvents(events) {
        var lastEvent = events[events.length - 1];
        var finalWinnerId;

        if (!events.length) {
            return;
        }

        events.forEach(function (event) {
            if (event.type === 'pass') {
                state.audio.playPass(event.playerId);
            }
        });

        if (lastEvent.type === 'round-end') {
            state.audio.playRoundEnd(lastEvent.result.roundWinnerId || lastEvent.result.nextStartingPlayerId);
            if (state.snapshot.phase === 'game-over') {
                finalWinnerId = state.snapshot.roundResult && state.snapshot.roundResult.finalWinnerId;
                state.audio.playVictory(finalWinnerId || 'red');
                spawnVictoryBurst(finalWinnerId || 'red');
            }
        }
    }

    function getMovesForSource(sourceIndex) {
        return state.snapshot.availableMoves[state.snapshot.currentPlayerId].filter(function (move) {
            return move.fromIndex === sourceIndex;
        });
    }

    function getActiveSourceIndex() {
        return state.drag ? state.drag.fromIndex : state.selectedSourceIndex;
    }

    function getHighlightedTargets() {
        var sourceIndex = getActiveSourceIndex();
        var targets = {};

        if (sourceIndex === null || sourceIndex === undefined) {
            return targets;
        }

        getMovesForSource(sourceIndex).forEach(function (move) {
            targets[move.toIndex] = true;
        });

        return targets;
    }

    function render() {
        var snapshot = state.snapshot;
        var status = getStatusContent(snapshot);
        var helperText = getTurnHelper(snapshot);
        var activeSourceIndex = getActiveSourceIndex();
        var highlightedTargets = getHighlightedTargets();

        elements.app.className = 'app turn-' + getTurnTheme(snapshot) + ' phase-' + snapshot.phase;
        elements.overlay.classList.toggle('hidden', snapshot.phase !== 'intro');
        elements.subtitle.textContent = snapshot.phase === 'intro'
            ? 'A tactile duel where the bigger adjacent card eats the smaller one.'
            : 'Five rounds. No scrolling. Drag anywhere on a card to make your move.';
        elements.roundPill.textContent = 'Round ' + snapshot.roundNumber + ' / ' + snapshot.totalRounds;
        elements.turnPill.textContent = getTurnPill(snapshot);
        elements.turnHelper.textContent = helperText;
        elements.scoreRed.textContent = String(snapshot.players.red.score);
        elements.scoreBlue.textContent = String(snapshot.players.blue.score);
        elements.roundRed.textContent = 'Round +' + snapshot.roundScores.red;
        elements.roundBlue.textContent = 'Round +' + snapshot.roundScores.blue;
        elements.panelRed.classList.toggle('is-active', snapshot.phase === 'round-active' && snapshot.currentPlayerId === 'red');
        elements.panelBlue.classList.toggle('is-active', snapshot.phase === 'round-active' && snapshot.currentPlayerId === 'blue');
        elements.statusKicker.textContent = status.kicker;
        elements.statusTitle.textContent = status.title;
        elements.statusMessage.textContent = status.message;
        elements.musicButton.textContent = 'Music: ' + (state.audio.enabled ? 'On' : 'Off');
        elements.musicButton.setAttribute('aria-pressed', String(state.audio.enabled));
        elements.fullscreenButton.textContent = document.fullscreenElement ? 'Leave Fullscreen' : 'Go Fullscreen';
        renderActionButtons(snapshot);
        renderBoard(snapshot, activeSourceIndex, highlightedTargets);
        syncDragClasses();
    }

    function renderActionButtons(snapshot) {
        if (snapshot.phase === 'intro') {
            elements.primaryButton.textContent = 'Start Game';
            elements.primaryButton.disabled = false;
            elements.secondaryButton.classList.add('hidden');
            return;
        }

        if (snapshot.phase === 'round-active') {
            elements.primaryButton.textContent = 'Round Live';
            elements.primaryButton.disabled = true;
            elements.secondaryButton.textContent = 'Back to Title';
            elements.secondaryButton.classList.remove('hidden');
            return;
        }

        if (snapshot.phase === 'round-end') {
            elements.primaryButton.textContent = 'Continue to Round ' + (snapshot.roundNumber + 1);
            elements.primaryButton.disabled = false;
            elements.secondaryButton.textContent = 'Back to Title';
            elements.secondaryButton.classList.remove('hidden');
            return;
        }

        elements.primaryButton.textContent = 'Play Again';
        elements.primaryButton.disabled = false;
        elements.secondaryButton.textContent = 'Back to Title';
        elements.secondaryButton.classList.remove('hidden');
    }

    function renderBoard(snapshot, activeSourceIndex, highlightedTargets) {
        var boardMarkup = snapshot.board.map(function (card, index) {
            var isHighlightedTarget = Boolean(highlightedTargets[index]);
            var isSelected = activeSourceIndex === index;
            var isCurrentPlayerCard = card && snapshot.phase === 'round-active' && card.owner === snapshot.currentPlayerId;
            var isActionable = card && isCurrentPlayerCard && getMovesForSource(index).length > 0;
            var isHoveredTarget = state.drag && state.drag.hoverTargetIndex === index && isHighlightedTarget;
            var cellClasses = ['board-cell'];
            var cardClasses;
            var cardMarkup;

            if (isHighlightedTarget) {
                cellClasses.push('is-drop-target');
            }

            if (!card) {
                return '<div class="' + cellClasses.join(' ') + '" data-index="' + index + '"></div>';
            }

            cardClasses = ['card', 'owner-' + card.owner];
            if (isCurrentPlayerCard) {
                cardClasses.push('is-current-turn');
            }
            if (isActionable) {
                cardClasses.push('is-actionable');
            }
            if (isSelected) {
                cardClasses.push('is-selected');
            }
            if (isHighlightedTarget) {
                cardClasses.push('is-drop-target');
            }
            if (isHoveredTarget) {
                cardClasses.push('is-hover-target');
            }

            cardMarkup = [
                '<button type="button" class="',
                cardClasses.join(' '),
                '" data-index="',
                index,
                '" data-owner="',
                card.owner,
                '" aria-label="',
                capitalize(card.owner),
                ' ',
                card.value,
                '">',
                '<span class="card-owner">',
                capitalize(card.owner),
                '</span>',
                '<strong class="card-value">',
                card.value,
                '</strong>',
                '<span class="card-tip">',
                isCurrentPlayerCard ? 'Drag me' : 'Target',
                '</span>',
                '</button>'
            ].join('');

            return '<div class="' + cellClasses.join(' ') + '" data-index="' + index + '">' + cardMarkup + '</div>';
        }).join('');

        elements.board.innerHTML = boardMarkup;
    }

    function syncDragClasses() {
        var hoveredIndex = state.drag ? state.drag.hoverTargetIndex : null;
        var cards = elements.board.querySelectorAll('.card');

        elements.board.classList.toggle('is-dragging', Boolean(state.drag));
        cards.forEach(function (cardElement) {
            var cardIndex = Number(cardElement.dataset.index);
            cardElement.classList.toggle('is-hover-target', hoveredIndex === cardIndex && getHighlightedTargets()[cardIndex]);
        });
    }

    function getTurnTheme(snapshot) {
        if (snapshot.phase === 'round-active') {
            return snapshot.currentPlayerId;
        }

        if (snapshot.phase === 'round-end' && snapshot.roundResult) {
            return snapshot.roundResult.nextStartingPlayerId;
        }

        return 'neutral';
    }

    function getTurnPill(snapshot) {
        if (snapshot.phase === 'intro') {
            return 'Ready to start';
        }

        if (snapshot.phase === 'round-active') {
            return capitalize(snapshot.currentPlayerId) + ' turn';
        }

        if (snapshot.phase === 'round-end') {
            return 'Round ' + snapshot.roundNumber + ' complete';
        }

        return 'Match complete';
    }

    function getTurnHelper(snapshot) {
        if (snapshot.phase === 'intro') {
            return 'The starting player is random in round 1, and the loser starts the next round.';
        }

        if (snapshot.phase === 'round-active') {
            if (state.selectedSourceIndex !== null) {
                return 'Drop onto a smaller adjacent enemy card. Diagonals count too.';
            }

            if (snapshot.availableMoves[snapshot.currentPlayerId].length === 0) {
                return capitalize(snapshot.currentPlayerId) + ' has no move and will pass automatically.';
            }

            return 'Drag anywhere on one of the glowing ' + snapshot.currentPlayerId + ' cards.';
        }

        if (snapshot.phase === 'round-end') {
            return capitalize(snapshot.roundResult.nextStartingPlayerId) + ' starts the next round.';
        }

        if (snapshot.roundResult && snapshot.roundResult.finalWinnerId) {
            return capitalize(snapshot.roundResult.finalWinnerId) + ' wins with the highest match score.';
        }

        return 'Both players finished with the same score.';
    }

    function getStatusContent(snapshot) {
        var transient = state.transientStatus;
        var winnerId;

        if (transient) {
            return transient;
        }

        if (snapshot.phase === 'intro') {
            return {
                kicker: 'How to win',
                title: 'Score higher than your rival after five rounds.',
                message: 'Start the match, then drag a bigger card onto a smaller adjacent enemy card to collect both values.'
            };
        }

        if (snapshot.phase === 'round-active') {
            return {
                kicker: capitalize(snapshot.currentPlayerId) + ' plays now',
                title: snapshot.lastAction.message,
                message: state.selectedSourceIndex !== null
                    ? 'Selected card: drop it on any glowing enemy target, or tap a target to confirm.'
                    : 'Only current-player cards with legal captures glow more brightly.'
            };
        }

        if (snapshot.phase === 'round-end') {
            return {
                kicker: snapshot.roundResult.isTie ? 'Round tied' : capitalize(snapshot.roundResult.roundWinnerId) + ' wins the round',
                title: snapshot.lastAction.message,
                message: 'Tap the main button to continue. The round loser opens the next round.'
            };
        }

        winnerId = snapshot.roundResult && snapshot.roundResult.finalWinnerId;
        return {
            kicker: winnerId ? capitalize(winnerId) + ' wins the match' : 'Match drawn',
            title: snapshot.lastAction.message,
            message: 'Tap Play Again for a fresh five-round battle.'
        };
    }

    function setTransientStatus(title, message) {
        clearTransientStatus();
        state.transientStatus = {
            kicker: 'Hint',
            title: title,
            message: message
        };
        state.transientTimerId = window.setTimeout(function () {
            clearTransientStatus();
            render();
        }, 1600);
        render();
    }

    function clearTransientStatus() {
        if (state.transientTimerId) {
            window.clearTimeout(state.transientTimerId);
            state.transientTimerId = 0;
        }
        state.transientStatus = null;
    }

    function updateDragGhost(sourceIndex, clientX, clientY) {
        var card = state.snapshot.board[sourceIndex];
        var sourceElement = elements.board.querySelector('.card[data-index="' + sourceIndex + '"]');
        var rect = sourceElement ? sourceElement.getBoundingClientRect() : null;
        var width = rect ? rect.width : 96;
        var height = rect ? rect.height : 96;

        if (!card) {
            return;
        }

        elements.dragGhost.className = 'drag-ghost owner-' + card.owner;
        elements.dragGhost.innerHTML = '<span class="card-owner">' + capitalize(card.owner) + '</span><strong class="card-value">' + card.value + '</strong><span class="card-tip">Drop me</span>';
        elements.dragGhost.style.width = width + 'px';
        elements.dragGhost.style.height = height + 'px';
        elements.dragGhost.style.left = clientX + 'px';
        elements.dragGhost.style.top = clientY + 'px';
        elements.dragGhost.classList.remove('hidden');
    }

    function findCardIndexFromPoint(x, y) {
        var target = document.elementFromPoint(x, y);
        var cardElement = target ? target.closest('.card') : null;

        if (!cardElement) {
            return null;
        }

        return Number(cardElement.dataset.index);
    }

    function getCardCenter(index) {
        var cardElement = elements.board.querySelector('.card[data-index="' + index + '"]');
        var rect;

        if (!cardElement) {
            rect = elements.boardFrame.getBoundingClientRect();
            return {
                x: rect.left + rect.width / 2,
                y: rect.top + rect.height / 2
            };
        }

        rect = cardElement.getBoundingClientRect();
        return {
            x: rect.left + rect.width / 2,
            y: rect.top + rect.height / 2
        };
    }

    function spawnCaptureEffects(sourceCenter, targetCenter, move) {
        var boardRect = elements.boardFrame.getBoundingClientRect();
        var midpoint = {
            x: (sourceCenter.x + targetCenter.x) / 2 - boardRect.left,
            y: (sourceCenter.y + targetCenter.y) / 2 - boardRect.top
        };
        var particleCount = 16;
        var particleIndex;
        var particle;
        var floatingScore;
        var color = move.actingPlayer === 'red' ? '#ff6481' : '#64acff';
        var angle;
        var distance;

        for (particleIndex = 0; particleIndex < particleCount; particleIndex += 1) {
            particle = document.createElement('div');
            particle.className = 'particle';
            angle = (Math.PI * 2 * particleIndex) / particleCount;
            distance = 34 + Math.random() * 46;
            particle.style.left = midpoint.x + 'px';
            particle.style.top = midpoint.y + 'px';
            particle.style.setProperty('--dx', Math.cos(angle) * distance + 'px');
            particle.style.setProperty('--dy', Math.sin(angle) * distance + 'px');
            particle.style.setProperty('--particle-color', color);
            elements.fxLayer.appendChild(particle);
            window.setTimeout(removeNode, 760, particle);
        }

        floatingScore = document.createElement('div');
        floatingScore.className = 'score-pop';
        floatingScore.style.left = midpoint.x + 'px';
        floatingScore.style.top = midpoint.y + 'px';
        floatingScore.style.setProperty('--accent-color', color);
        floatingScore.textContent = '+' + move.gain;
        elements.fxLayer.appendChild(floatingScore);
        window.setTimeout(removeNode, 1100, floatingScore);
    }

    function spawnVictoryBurst(playerId) {
        var boardRect = elements.boardFrame.getBoundingClientRect();
        var center = {
            x: boardRect.width / 2,
            y: boardRect.height / 2
        };
        var count = 28;
        var index;
        var particle;
        var angle;
        var distance;
        var color = playerId === 'blue' ? '#64acff' : '#ff6481';

        for (index = 0; index < count; index += 1) {
            particle = document.createElement('div');
            particle.className = 'particle big';
            angle = (Math.PI * 2 * index) / count;
            distance = 60 + Math.random() * 120;
            particle.style.left = center.x + 'px';
            particle.style.top = center.y + 'px';
            particle.style.setProperty('--dx', Math.cos(angle) * distance + 'px');
            particle.style.setProperty('--dy', Math.sin(angle) * distance + 'px');
            particle.style.setProperty('--particle-color', color);
            elements.fxLayer.appendChild(particle);
            window.setTimeout(removeNode, 980, particle);
        }
    }

    function removeNode(node) {
        if (node && node.parentNode) {
            node.parentNode.removeChild(node);
        }
    }

    function shakeCard(index) {
        var element = elements.board.querySelector('.card[data-index="' + index + '"]');

        if (!element) {
            return;
        }

        element.classList.remove('is-invalid');
        void element.offsetWidth;
        element.classList.add('is-invalid');
    }

    function distanceBetween(x1, y1, x2, y2) {
        var dx = x1 - x2;
        var dy = y1 - y2;
        return Math.sqrt(dx * dx + dy * dy);
    }

    initialize();
}());

