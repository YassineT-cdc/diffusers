(function (globalScope, factory) {
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = factory();
        return;
    }

    globalScope.InferiorLogic = factory();
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
    'use strict';

    var PLAYER_IDS = Object.freeze(['red', 'blue']);
    var TOTAL_ROUNDS = 5;
    var GRID_SIZE = 4;
    var BOARD_SIZE = GRID_SIZE * GRID_SIZE;

    function capitalize(value) {
        return value.charAt(0).toUpperCase() + value.slice(1);
    }

    function cloneCard(card) {
        return card ? Object.assign({}, card) : null;
    }

    function cloneBoard(board) {
        return board.map(cloneCard);
    }

    function randomChoice(values, randomFunction) {
        return values[Math.floor(randomFunction() * values.length)];
    }

    function shuffle(values, randomFunction) {
        var copy = values.slice();
        var index;
        var swapIndex;
        var temp;

        for (index = copy.length - 1; index > 0; index -= 1) {
            swapIndex = Math.floor(randomFunction() * (index + 1));
            temp = copy[index];
            copy[index] = copy[swapIndex];
            copy[swapIndex] = temp;
        }

        return copy;
    }

    function createDeck(owner, roundNumber) {
        return Array.from({ length: 8 }, function (_, offset) {
            var value = offset + 1;
            return {
                id: owner + '-' + roundNumber + '-' + value,
                owner: owner,
                value: value
            };
        });
    }

    function createRoundBoard(roundNumber, randomFunction) {
        var shuffledCards = shuffle(
            createDeck('red', roundNumber).concat(createDeck('blue', roundNumber)),
            randomFunction || Math.random
        );

        return shuffledCards.map(function (card, index) {
            return Object.assign({}, card, { index: index });
        });
    }

    function indexToCoordinates(index) {
        return {
            row: Math.floor(index / GRID_SIZE),
            column: index % GRID_SIZE
        };
    }

    function areAdjacent(firstIndex, secondIndex) {
        var first;
        var second;

        if (firstIndex === secondIndex) {
            return false;
        }

        first = indexToCoordinates(firstIndex);
        second = indexToCoordinates(secondIndex);

        return Math.abs(first.row - second.row) <= 1 && Math.abs(first.column - second.column) <= 1;
    }

    function getAdjacentIndices(index) {
        var base = indexToCoordinates(index);
        var adjacent = [];
        var row;
        var column;

        for (row = base.row - 1; row <= base.row + 1; row += 1) {
            for (column = base.column - 1; column <= base.column + 1; column += 1) {
                if (row === base.row && column === base.column) {
                    continue;
                }

                if (row < 0 || row >= GRID_SIZE || column < 0 || column >= GRID_SIZE) {
                    continue;
                }

                adjacent.push(row * GRID_SIZE + column);
            }
        }

        return adjacent;
    }

    function getOpponent(playerId) {
        return playerId === 'red' ? 'blue' : 'red';
    }

    function isValidCapture(board, fromIndex, toIndex, playerId) {
        var source = board[fromIndex];
        var target = board[toIndex];

        if (!source || !target) {
            return false;
        }

        if (source.owner !== playerId || target.owner === playerId) {
            return false;
        }

        if (!areAdjacent(fromIndex, toIndex)) {
            return false;
        }

        return source.value > target.value;
    }

    function getAvailableMoves(board, playerId) {
        var moves = [];

        board.forEach(function (card, fromIndex) {
            if (!card || card.owner !== playerId) {
                return;
            }

            getAdjacentIndices(fromIndex).forEach(function (toIndex) {
                if (!isValidCapture(board, fromIndex, toIndex, playerId)) {
                    return;
                }

                moves.push({
                    fromIndex: fromIndex,
                    toIndex: toIndex,
                    gain: card.value + board[toIndex].value
                });
            });
        });

        return moves;
    }

    function countCards(board) {
        return board.reduce(function (summary, card) {
            if (!card) {
                return summary;
            }

            summary.total += 1;
            summary[card.owner] += 1;
            summary.values[card.owner].push(card.value);
            return summary;
        }, {
            total: 0,
            red: 0,
            blue: 0,
            values: {
                red: [],
                blue: []
            }
        });
    }

    function InferiorGame(randomFunction) {
        this.randomFunction = randomFunction || Math.random;
        this.resetGame();
    }

    InferiorGame.prototype.resetGame = function () {
        var randomStarter = randomChoice(PLAYER_IDS, this.randomFunction);

        this.players = {
            red: { id: 'red', label: 'Red', score: 0 },
            blue: { id: 'blue', label: 'Blue', score: 0 }
        };
        this.roundNumber = 0;
        this.phase = 'intro';
        this.currentPlayerId = randomStarter;
        this.startingPlayerId = randomStarter;
        this.nextStartingPlayerId = randomStarter;
        this.roundScores = { red: 0, blue: 0 };
        this.board = Array(BOARD_SIZE).fill(null);
        this.roundResult = null;
        this.lastAction = {
            kind: 'intro',
            message: capitalize(randomStarter) + ' is currently favoured to begin round 1.'
        };

        return this.getSnapshot();
    };

    InferiorGame.prototype.startGame = function () {
        this.resetGame();
        return this.startNextRound();
    };

    InferiorGame.prototype.startNextRound = function () {
        if (this.roundNumber >= TOTAL_ROUNDS) {
            return this.getSnapshot();
        }

        this.roundNumber += 1;
        this.phase = 'round-active';
        this.startingPlayerId = this.nextStartingPlayerId;
        this.currentPlayerId = this.startingPlayerId;
        this.roundScores = { red: 0, blue: 0 };
        this.roundResult = null;
        this.board = createRoundBoard(this.roundNumber, this.randomFunction);
        this.lastAction = {
            kind: 'round-start',
            message: 'Round ' + this.roundNumber + ' begins. ' + capitalize(this.currentPlayerId) + ' plays first.'
        };

        return this.resolveTurnState();
    };

    InferiorGame.prototype.resolveTurnState = function () {
        var events = [];
        var safety = 0;
        var currentMoves;
        var opponentId;
        var opponentMoves;
        var result;

        if (this.phase !== 'round-active') {
            return this.getSnapshot(events);
        }

        while (safety < 3) {
            safety += 1;
            currentMoves = getAvailableMoves(this.board, this.currentPlayerId);
            if (currentMoves.length > 0) {
                if (events.length > 0) {
                    this.lastAction = {
                        kind: 'pass',
                        message: capitalize(events[events.length - 1].playerId) + ' cannot capture. ' + capitalize(this.currentPlayerId) + ' takes the turn.'
                    };
                }

                return this.getSnapshot(events);
            }

            opponentId = getOpponent(this.currentPlayerId);
            opponentMoves = getAvailableMoves(this.board, opponentId);

            if (opponentMoves.length === 0) {
                result = this.finishRound();
                events.push({ type: 'round-end', result: result });
                return this.getSnapshot(events);
            }

            events.push({
                type: 'pass',
                playerId: this.currentPlayerId,
                toPlayerId: opponentId
            });
            this.currentPlayerId = opponentId;
        }

        return this.getSnapshot(events);
    };

    InferiorGame.prototype.finishRound = function () {
        var roundWinnerId = null;
        var roundLoserId;
        var finalWinnerId = null;
        var result;

        if (this.roundScores.red !== this.roundScores.blue) {
            roundWinnerId = this.roundScores.red > this.roundScores.blue ? 'red' : 'blue';
        }

        roundLoserId = roundWinnerId ? getOpponent(roundWinnerId) : getOpponent(this.startingPlayerId);
        this.nextStartingPlayerId = roundLoserId;
        this.phase = this.roundNumber >= TOTAL_ROUNDS ? 'game-over' : 'round-end';

        result = {
            roundNumber: this.roundNumber,
            roundScores: Object.assign({}, this.roundScores),
            roundWinnerId: roundWinnerId,
            roundLoserId: roundLoserId,
            isTie: roundWinnerId === null,
            nextStartingPlayerId: this.nextStartingPlayerId,
            finalWinnerId: null,
            finalTie: false
        };

        if (this.phase === 'game-over') {
            if (this.players.red.score !== this.players.blue.score) {
                finalWinnerId = this.players.red.score > this.players.blue.score ? 'red' : 'blue';
            }

            result.finalWinnerId = finalWinnerId;
            result.finalTie = finalWinnerId === null;
            this.lastAction = {
                kind: 'game-over',
                message: finalWinnerId
                    ? 'Game over. ' + capitalize(finalWinnerId) + ' wins the match.'
                    : 'Game over. The match ends in a draw.'
            };
        } else {
            this.lastAction = {
                kind: 'round-end',
                message: result.isTie
                    ? 'Round ' + this.roundNumber + ' ends in a tie. ' + capitalize(this.nextStartingPlayerId) + ' starts next.'
                    : 'Round ' + this.roundNumber + ' is over. ' + capitalize(roundLoserId) + ' starts next.'
            };
        }

        this.roundResult = result;
        return result;
    };

    InferiorGame.prototype.tryCapture = function (fromIndex, toIndex) {
        var source;
        var target;
        var gain;
        var actingPlayer;
        var snapshot;

        if (this.phase !== 'round-active') {
            return {
                ok: false,
                reason: 'round-not-active',
                snapshot: this.getSnapshot()
            };
        }

        if (!isValidCapture(this.board, fromIndex, toIndex, this.currentPlayerId)) {
            return {
                ok: false,
                reason: 'invalid-capture',
                snapshot: this.getSnapshot()
            };
        }

        source = this.board[fromIndex];
        target = this.board[toIndex];
        gain = source.value + target.value;
        actingPlayer = this.currentPlayerId;

        this.board[fromIndex] = null;
        this.board[toIndex] = null;
        this.players[actingPlayer].score += gain;
        this.roundScores[actingPlayer] += gain;
        this.currentPlayerId = getOpponent(actingPlayer);
        this.lastAction = {
            kind: 'capture',
            message: capitalize(actingPlayer) + ' captures ' + source.value + ' + ' + target.value + ' and gains ' + gain + ' points.',
            move: {
                fromIndex: fromIndex,
                toIndex: toIndex,
                gain: gain,
                actingPlayer: actingPlayer,
                source: cloneCard(source),
                target: cloneCard(target)
            }
        };

        snapshot = this.resolveTurnState();

        return {
            ok: true,
            snapshot: snapshot,
            move: {
                fromIndex: fromIndex,
                toIndex: toIndex,
                gain: gain,
                actingPlayer: actingPlayer,
                source: cloneCard(source),
                target: cloneCard(target)
            }
        };
    };

    InferiorGame.prototype.getSnapshot = function (events) {
        return {
            totalRounds: TOTAL_ROUNDS,
            roundNumber: this.roundNumber,
            phase: this.phase,
            currentPlayerId: this.currentPlayerId,
            startingPlayerId: this.startingPlayerId,
            nextStartingPlayerId: this.nextStartingPlayerId,
            players: {
                red: Object.assign({}, this.players.red),
                blue: Object.assign({}, this.players.blue)
            },
            roundScores: Object.assign({}, this.roundScores),
            board: cloneBoard(this.board),
            availableMoves: {
                red: getAvailableMoves(this.board, 'red'),
                blue: getAvailableMoves(this.board, 'blue')
            },
            lastAction: Object.assign({}, this.lastAction),
            roundResult: this.roundResult ? JSON.parse(JSON.stringify(this.roundResult)) : null,
            events: events || []
        };
    };

    return {
        PLAYER_IDS: PLAYER_IDS,
        TOTAL_ROUNDS: TOTAL_ROUNDS,
        GRID_SIZE: GRID_SIZE,
        BOARD_SIZE: BOARD_SIZE,
        createRoundBoard: createRoundBoard,
        getAdjacentIndices: getAdjacentIndices,
        areAdjacent: areAdjacent,
        getOpponent: getOpponent,
        isValidCapture: isValidCapture,
        getAvailableMoves: getAvailableMoves,
        countCards: countCards,
        InferiorGame: InferiorGame
    };
}));

