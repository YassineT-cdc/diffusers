# Inferior

Inferior is a local HTML5 two-player touch game designed for one shared screen.

## How to launch

Open `index.html` directly from your file explorer.

No web server, build step or dependency install is required to play.

## How to play

- Five rounds are played.
- Each round starts with a shuffled 4×4 grid of revealed cards.
- Red owns cards 1 to 8, and Blue owns cards 1 to 8.
- Players take turns.
- On your turn, drag one of your cards onto an adjacent enemy card.
- Diagonals are valid.
- Your card must be strictly greater than the enemy card.
- Both cards are removed.
- The active player scores the sum of both card values.
- If a player cannot move, the turn passes automatically.
- If nobody can move, the round ends.
- The loser of a round starts the next round.
- The player with the highest total score after round 5 wins the match.

## Controls

- Touch and drag works on the whole card.
- Mouse drag and click also work.
- You can also tap one of your cards, then tap a legal enemy target.
- Fullscreen is recommended and can be toggled from the interface.
- Music is enabled by default and starts on the first interaction allowed by the browser.

## Files

- `index.html`: main entry point
- `css/styles.css`: layout, responsive design, colors and animations
- `js/game-logic.js`: reusable game rules and state engine
- `js/app.js`: UI, touch controls, effects, fullscreen and music
- `tests/smoke-test.cjs`: local smoke test for the core rules
- `tests/manual-checklist.md`: manual checks for touch, responsive layout and fullscreen

## Optional local check

If Node.js is available, you can run the smoke test:

```powershell
node tests/smoke-test.cjs
```

