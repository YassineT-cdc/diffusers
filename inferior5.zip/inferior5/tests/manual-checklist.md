# Manual checklist

## Core gameplay

- Open `index.html` directly from the file explorer.
- Confirm the intro screen appears with the two-hand finger illustration.
- Start a new match.
- Verify round 1 starts with a 4×4 grid of 16 revealed cards.
- Verify Red owns exactly eight cards and Blue owns exactly eight cards.
- Verify values 1 to 8 appear once per player.
- Verify the starting player is random.
- Drag a legal card onto a smaller adjacent enemy card.
- Confirm both cards disappear.
- Confirm the active player gains the sum of both values.
- Confirm turns alternate automatically.
- Confirm a player with no move passes automatically.
- Confirm a round ends when neither player can move.
- Confirm the loser of the round starts the next round.
- Confirm the match ends after round 5.
- Confirm the highest total score wins.

## Touch and pointer handling

- Drag from the center of a card.
- Drag from each edge of a card.
- Drag with a mouse.
- Drag with one finger on a phone.
- Tap one own card, then tap a legal target.
- Try an illegal drop and confirm the game stays stable.

## Layout and responsiveness

- Verify the game fits on screen with no page scrolling.
- Verify the board remains square on desktop.
- Verify the game remains playable in portrait mode.
- Verify the game remains playable in landscape mode.
- Verify the background tint changes with the active player.

## Media and framing

- Confirm the music toggle starts as On.
- Confirm music starts after the first allowed interaction.
- Confirm the fullscreen button works when the browser allows it.
- Embed the game in an iframe and confirm it still plays.

