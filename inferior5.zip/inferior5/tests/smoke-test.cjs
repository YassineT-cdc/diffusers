const logic = require('../js/game-logic.js');

function assert(condition, message) {
    if (!condition) {
        throw new Error(message);
    }
}

function hasExactValues(values) {
    return values.slice().sort((left, right) => left - right).join(',') === '1,2,3,4,5,6,7,8';
}

function testRoundBoardShape() {
    const board = logic.createRoundBoard(1, () => 0.5);
    const summary = logic.countCards(board);

    assert(board.length === 16, 'A round board must contain 16 slots.');
    assert(summary.total === 16, 'A fresh round board must contain 16 cards.');
    assert(summary.red === 8, 'Red must start with 8 cards.');
    assert(summary.blue === 8, 'Blue must start with 8 cards.');
    assert(hasExactValues(summary.values.red), 'Red values must be exactly 1 to 8.');
    assert(hasExactValues(summary.values.blue), 'Blue values must be exactly 1 to 8.');
}

function testAdjacencyAndCaptureRules() {
    const board = Array(16).fill(null);

    board[0] = { owner: 'red', value: 5 };
    board[1] = { owner: 'blue', value: 4 };
    board[5] = { owner: 'blue', value: 6 };
    board[15] = { owner: 'blue', value: 1 };

    assert(logic.areAdjacent(0, 1), 'Horizontal neighbours must be adjacent.');
    assert(logic.areAdjacent(0, 5), 'Diagonal neighbours must be adjacent.');
    assert(!logic.areAdjacent(0, 15), 'Distant cards must not be adjacent.');
    assert(logic.isValidCapture(board, 0, 1, 'red'), 'A bigger adjacent card must capture a smaller enemy card.');
    assert(!logic.isValidCapture(board, 0, 5, 'red'), 'A smaller card must not capture a bigger enemy card.');
    assert(!logic.isValidCapture(board, 0, 15, 'red'), 'A non adjacent card must not capture.');
}

function testGameMoveAndScoring() {
    const game = new logic.InferiorGame(() => 0.42);
    const initialSnapshot = game.startGame();
    const currentPlayer = initialSnapshot.currentPlayerId;
    const move = initialSnapshot.availableMoves[currentPlayer][0];
    const beforeScore = initialSnapshot.players[currentPlayer].score;
    const result = game.tryCapture(move.fromIndex, move.toIndex);

    assert(result.ok, 'The first available move must be playable.');
    assert(result.snapshot.players[currentPlayer].score === beforeScore + result.move.gain, 'The active player score must increase by the captured total.');
    assert(result.snapshot.board[move.fromIndex] === null, 'The source card must be removed after a capture.');
    assert(result.snapshot.board[move.toIndex] === null, 'The target card must be removed after a capture.');
}

function testAutomaticPassAndRoundEnd() {
    const game = new logic.InferiorGame(() => 0.1);

    game.phase = 'round-active';
    game.roundNumber = 1;
    game.currentPlayerId = 'red';
    game.startingPlayerId = 'red';
    game.nextStartingPlayerId = 'red';
    game.roundScores = { red: 0, blue: 0 };
    game.players.red.score = 0;
    game.players.blue.score = 0;
    game.board = Array(16).fill(null);
    game.board[0] = { owner: 'red', value: 1 };
    game.board[1] = { owner: 'blue', value: 8 };

    const snapshotAfterPass = game.resolveTurnState();

    assert(snapshotAfterPass.phase === 'round-active', 'The round must continue when the opponent still has a move.');
    assert(snapshotAfterPass.currentPlayerId === 'blue', 'The turn must pass automatically to the player who can move.');

    game.phase = 'round-active';
    game.currentPlayerId = 'red';
    game.startingPlayerId = 'red';
    game.board = Array(16).fill(null);
    game.board[0] = { owner: 'red', value: 1 };
    game.board[1] = { owner: 'blue', value: 1 };
    game.roundScores = { red: 2, blue: 5 };

    const snapshotAfterStall = game.resolveTurnState();

    assert(snapshotAfterStall.phase === 'round-end', 'The round must end when nobody can capture.');
    assert(snapshotAfterStall.roundResult.roundWinnerId === 'blue', 'The highest round score must win the round.');
    assert(snapshotAfterStall.roundResult.nextStartingPlayerId === 'red', 'The round loser must start the next round.');
}

function run() {
    testRoundBoardShape();
    testAdjacencyAndCaptureRules();
    testGameMoveAndScoring();
    testAutomaticPassAndRoundEnd();
    console.log('Smoke tests passed for Inferior.');
}

run();

